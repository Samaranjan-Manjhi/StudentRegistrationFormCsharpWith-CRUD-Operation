﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentForm_DB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        SqlConnection conn = new SqlConnection("Data Source=SAMARANJANLAPTO\\SQLEXPRESS;Initial Catalog=StudentDetails;Integrated Security=True");
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Insertion Code
            int prn = int.Parse(textBox1.Text);
            string name = textBox2.Text;
            DateTime dob = DateTime.Parse(dateTimePicker1.Text);
            string sex = "";
            if (radioButton1.Checked == true)
            {
                sex = "Male";
            }
            else
            {
                sex = "Female";
            }
            string phone = textBox3.Text;
            string address = comboBox1.Text;
            string parent = textBox4.Text;
            conn.Open();
            SqlCommand cmd = new SqlCommand("exec InsertStu_Info '" + prn + "', '" + name + "', '" + dob + "', '" + sex + "', '" + phone + "', '" + address + "', '" + parent + "'", conn);
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Successfully Inserted...");
            GetStuList();
        }

        void GetStuList()
        {
            SqlCommand cmd = new SqlCommand("exec ListStu_Info", conn);
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Updation Code
            int prn = int.Parse(textBox1.Text);
            string name = textBox2.Text;
            DateTime dob = DateTime.Parse(dateTimePicker1.Text);
            string sex = "";
            if (radioButton1.Checked == true)
            {
                sex = "Male";
            }
            else
            {
                sex = "Female";
            }
            string phone = textBox3.Text;
            string address = comboBox1.Text;
            string parent = textBox4.Text;
            conn.Open();
            SqlCommand cmd = new SqlCommand("exec UpdateStu_Info '" + prn + "', '" + name + "', '" + dob + "', '" + sex + "', '" + phone + "', '" + address + "', '" + parent + "'", conn);
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Successfully Updated...");
            GetStuList();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Deletion Code
            if (MessageBox.Show("Are you sure want to delete this Information ?", "Delete Information", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                int prn = int.Parse(textBox1.Text);
                conn.Open();
                SqlCommand cmd = new SqlCommand("exec DeleteStu_Info '" + prn + "'", conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Successfully Deleted...");
                GetStuList();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Search for specific result
            int prn = int.Parse(textBox1.Text);
            SqlCommand cmd = new SqlCommand("exec SearchStu_Info '" + prn + "'", conn);
            conn.Close();
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
}
